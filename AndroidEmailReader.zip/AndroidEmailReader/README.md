# Android Email Reader — GitHub APK build

This is an Android Studio starter project. It reads up to 20 recent messages from an IMAPS inbox and refreshes every 30 seconds while the app is open.

## Build an APK using only your phone and GitHub

1. Download and extract this ZIP on your phone.
2. In a browser, sign in to https://github.com and create a new repository. Give it a name such as `AndroidEmailReader` and set it to **Private**. Do not initialize it with a README.
3. Open the new repository, choose **Add file → Upload files**, and upload the *contents* of this extracted project folder. Make sure `.github/workflows/build-apk.yml` is included. If GitHub's mobile upload page hides dot-folders, use the browser's **Desktop site** option and verify the workflow file is uploaded.
4. Commit the uploaded files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build Android APK**. If prompted, enable GitHub Actions for the repository.
6. The workflow should start automatically after the commit. Wait for the run to finish with a green check mark. You can also open the workflow and choose **Run workflow**.
7. Open the completed workflow run. Scroll to **Artifacts** and download `EmailReader-debug-apk`.
8. Extract the downloaded artifact ZIP. Tap `app-debug.apk` to install it. Android may ask you to allow installs from your browser or Files app.

## What the workflow does

GitHub Actions installs Java 17, Gradle 8.9, and the Android SDK, then runs `gradle assembleDebug`. It uploads the resulting debug APK as a downloadable artifact.

## Important limitations

- This is a starter app, not a production-ready mail client.
- The current starter code supports IMAPS only; POP3S, multi-account lists, CSV/TXT import, OAuth2, and secure persistent credential storage have not yet been implemented.
- Gmail and some other providers require OAuth2 or provider-specific app passwords. Do not use your normal account password if the provider offers a safer app-password or OAuth option.
- The app refreshes only while open. It does not provide continuous background monitoring.
- The debug APK is suitable for personal testing, not Play Store publication.
